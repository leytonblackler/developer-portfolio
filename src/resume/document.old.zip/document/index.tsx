import React, { type FunctionComponent } from "react";
import { Tailwind, CSS as Css } from "@fileforge/react-print";
import tailwindConfig from "../../../tailwind.config";
import { ResumeHeader } from "./components/header";
import { ResumeProjectsSection } from "./sections/projects";
import { ResumeExperienceSection } from "./sections/experience";
import { ResumeTechnicalSkillsSection } from "./sections/technical-skills";
import { ResumeBuiltWithReactSection } from "./sections/built-with-react";
import { ResumeEducationSection } from "./sections/education";
import { ResumeProfileSection } from "./sections/profile";
import { ReferencesSection } from "./sections/references";
import {
  type ResumePersonalOverviewSectionDataFragment,
  type ResumeDataFragment,
} from "@/hygraph/generated/graphql";
import { cn } from "@/utils/styling/cn";
import { ColorScheme } from "@/hooks/color-scheme/types";

export const ResumeDocument: FunctionComponent<
  { colorScheme: ColorScheme } & Pick<
    ResumeDataFragment,
    "technologies" | "primaryEducationalInstitution" | "companies" | "projects"
  > &
    Pick<
      ResumePersonalOverviewSectionDataFragment,
      "name" | "pronouns" | "description"
    >
> = ({
  colorScheme,
  name,
  pronouns,
  description,
  technologies,
  primaryEducationalInstitution,
  companies,
  projects,
}) => {
  /**
   * Determine if the color scheme is dark mode.
   */
  const isDarkMode = colorScheme === ColorScheme.Dark;

  return (
    <Tailwind config={tailwindConfig}>
      <Css>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap');
        @page {
          size: a4;
          margin: 0;
        }
        `}
      </Css>
      <div
        className={cn(
          isDarkMode ? "bg-gray-950" : "bg-gray-100", // root-bg
          "h-screen w-screen",
          "flex flex-col p-2"
        )}
        style={{
          fontFamily: "Plus Jakarta Sans",
        }}
      >
        <ResumeHeader isDarkMode={isDarkMode} name={name} pronouns={pronouns} />
        <main className="flex flex-1 flex-col">
          <div className="flex flex-1 flex-row">
            <div className="mr-0.5 flex flex-1 flex-col">
              <ResumeProfileSection
                isDarkMode={isDarkMode}
                className="mb-0.5 flex-1"
                description={description}
              />
              <ResumeTechnicalSkillsSection
                isDarkMode={isDarkMode}
                className="mt-0.5 flex-1"
                technologies={technologies}
              />
            </div>
            <div className="ml-0.5 flex flex-1 flex-col">
              <ResumeExperienceSection
                isDarkMode={isDarkMode}
                className="mb-0.5 flex-1"
                companies={companies}
              />
              <ResumeEducationSection
                isDarkMode={isDarkMode}
                className="my-0.5 h-fit max-h-fit shrink-0"
                primaryEducationalInstitution={primaryEducationalInstitution}
              />
              <ResumeProjectsSection
                isDarkMode={isDarkMode}
                className="my-0.5 flex-1"
                projects={projects}
              />
              <div className="mt-0.5 flex flex-row">
                <ReferencesSection
                  isDarkMode={isDarkMode}
                  className="mr-1 flex-1"
                />
              </div>
            </div>
          </div>
          <ResumeBuiltWithReactSection
            isDarkMode={isDarkMode}
            className="mt-1"
          />
        </main>
      </div>
    </Tailwind>
  );
};
