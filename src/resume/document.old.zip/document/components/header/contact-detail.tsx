import React from "react";
import { type FunctionComponent } from "react";
import { type IconType } from "react-icons";
import { cn } from "@/utils/styling/cn";

interface ResumeContactDetailProps {
  isDarkMode: boolean;
  href: string;
  icon: IconType;
  className?: string;
  children: string;
}

export const ResumeContactDetail: FunctionComponent<
  ResumeContactDetailProps
> = ({ isDarkMode, href, icon: Icon, className, children }) => (
  <a
    href={href}
    className={cn(
      "flex flex-row",
      "items-center",
      isDarkMode ? "text-gray-400" : "text-gray-700", // hero-text-secondary,
      "text-opacity-70",
      className
    )}
  >
    <Icon
      style={{
        width: 16,
        height: 16,
      }}
    />
    <span className="ml-2 text-xs font-medium leading-none">{children}</span>
  </a>
);
